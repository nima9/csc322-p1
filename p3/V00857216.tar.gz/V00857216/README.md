# Project 3 for CSC 322 Class (with Alex, Carter, and Nima - Group 15)

## Student Names and IDs for Group 15:

- Alexander Lambert - V00956639
- Carter Cranston   - V01000607
- Nima Mohajeri     - V00857216

## This submission contains the following files:

- `phil.smv`
- `phil.extended.smv`
- `README.md`
- `solution.pdf`

<br/>

<details><summary>How to run `phil.smv`.</summary>

#### To use `phil.smv`, run this cli command:
```
NuSMV phil.smv
```

</details>



<details><summary>How to run `phil.extended.smv`.</summary>

#### To use `phil.extended.smv`, run this cli command:
```
NuSMV phil.extended.smv
```

</details>